﻿//this program is sued to selct a document and find the potential documnet numbers by parsing through the document. The potenial doc numbers are put in a file named TCE.test

using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.IO;
using Microsoft.Office.Interop.Word;
using Word = Microsoft.Office.Interop.Word;
using System.Text.RegularExpressions;

namespace testTCE
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}
		//this function tells if the string could be a document number or not
		public bool matched(string s)
		{
			if (s.Contains("SOP") == true || s.Contains("DWI") == true)
				return false;
			if (s.Count()==0)
				return false;
			//the format of the DocNumber is such that the size is between 8-11
			if (s.Count() <8 || s.Count()>11)
				return false;
			if (s[0] == '5' || s[0] == '6' || s[0]=='4' || s[0]=='1')
			{
				for(int i=0;i<8;i++)
				{
					if (s[i] >= '0' && s[i] <= '9')
					{
						continue;
					}
					else
						return false;
				}
				return true;
			}
			return false;
		}
		//This function will parse the word and check if a substring is a doc number match or not
		public string Parse_String(string s)
		{
			for(int i=0;i<s.Count();i++)
			{
				//count of doc number is always 8
				if (i + 8 <= s.Count())
				{
					if (matched(s.Substring(i, 8)) == true)
					{
						//the string might have docnumb/revnumb, this if handles that condition
						if (s.Count() >= 10)
						{
							try
							{
								if (s.Substring(i, 9).Contains("/") == true)
								{
									int end = 10;
									if (s.Count() == 11)
									{
										if ((s[10] >= 'A' && s[10] <= 'Z') || (s[10] >= 'a' && s[10] <= 'z'))
										{
											end = 11;
										}
									}
									return s.Substring(i, end);
								}
							}
							catch
							{ return s.Substring(i, 8); }
						}
						return s.Substring(i, 8);
					}
				}
			}
			return "EXIT";
		}
		//The following function will tell us if the required file exists or not and deletes it. This is only a debug function not used by program.
		public void display_file(string s)
		{
			using (StreamReader sr = new StreamReader(s))
			{
				string line1 = sr.ReadToEnd();
				Console.WriteLine(line1);
				sr.Close();
			}
			MessageBox.Show("OK to exit!!");
			File.Delete(s);
		}
		//This function is used to create a temporary file for each file selection
		public string Getpath(string s, int count)
		{			
			string sp = JoinFIle(s, count.ToString());
			return sp;
		}
		// this function places the document numbers in a text file for .C program to easily read. path is TCE.txt contains all the doc numbers, path2 is the revision.txt which contains
		//revision, s is the doc number and rev is its revision
		public int searchinTCE(string path, string path2,string s,string rev)
		{
			List<string> PN = new List<string>();
			List<string> revision = new List<string>();
			List<string> description = new List<string>();
			
			
				string text = s;
				if (!File.Exists(path))
				{
					using (StreamWriter sw = File.CreateText(path))
					{
						sw.WriteLine(text);
						sw.Close();
					}
				}
				else
				{
					int duplicates = 0;
					//to check if the docuemnt number along with the revision number has already been updated or not
					using (StreamReader sr = new StreamReader(path))
					{
						string line1 = sr.ReadToEnd();
						if (line1.Contains(s) == true)
						{
							string[] array = line1.Split('\n');
							for(int start=0;start<array.Count();start++)
							{
								if(array[start].Contains(s)==true)
								{
									string replacer = "";
									using (StreamReader sr2 = new StreamReader(path2))
									{
										string line2 = sr2.ReadToEnd();
										string[] buffer = line2.Split('\n');
									    // updates the revision if the prev revision exists 
										if (buffer[start].Equals(rev) == false && rev.Count()>0 && rev.Contains("NULL")==false)
										{
											if(buffer[start].Contains("NULL")==true)
												buffer[start] =s+" "+ rev+"\r";
											else
											{
												buffer[start] =buffer[start] + "&" + rev+ "\r";
											}
										}
										for(int ic=0;ic<buffer.Count()-2;ic++)
										{
											replacer = replacer + buffer[ic] + "\n";
										}
										replacer = replacer + buffer[buffer.Count()-2];
										sr2.Close();
									
									}
									// Deletes old file and replaces the old one with the updated revison.
									File.Delete(path2);
									using (StreamWriter swr2 = File.CreateText(path2))
									{
										swr2.WriteLine(replacer);
										swr2.Close();
									}
									break;
								}
							}
							//MessageBox.Show("ALERT Caught!");
							duplicates= 1;
							return 1;
						}
						sr.Close();
					}
					if (duplicates == 0)
					{
						using (StreamWriter swr = File.AppendText(path))
						{
							swr.WriteLine(text);
							swr.Close();
						}
					}
				}
			
			//MessageBox.Show("Execution Completed");
			return 0;
		}
		// this function places the document numbers in a text file for .C program to easily read
		public void PutRevision(string path1, string path,string rq,string s)
		{
			//Console.WriteLine(rq + "  " + s);
			List<string> PN = new List<string>();
			List<string> revision = new List<string>();
			List<string> description = new List<string>();
			//string path = System.IO.Directory.GetCurrentDirectory() + "\\revision.txt";
			//path = Getpath(path);
			for (int i = 0; i < 1; i++)
			{
				string text = rq+ " " +s;
				if (!File.Exists(path))
				{
					using (StreamWriter sw = File.CreateText(path))
					{
						sw.WriteLine(text);
						sw.Close();
					}
				}
				else
				{
					int duplicates = 0;
					using (StreamReader sr = new StreamReader(path))
					{
						string line1 = sr.ReadToEnd();
						if (line1.Contains(s) == true)
						{
							//MessageBox.Show("ALERT Caught!");
							duplicates = 1;
						}
						sr.Close();
					}
					if (duplicates >-1)
					{
						using (StreamWriter swr = File.AppendText(path))
						{
							swr.WriteLine(text);
							swr.Close();
						}
					}
				}
			}
			//MessageBox.Show("Execution Completed");
		}
		public static class Prompt //Lets the user insert a string, not used in this program was used initially in the development phases
		{
			//The following code let's the user edit a field in the textbox
			public static string ShowDialog(string text, string caption)
			{
				Form prompt = new Form()
				{
					Width = 500,
					Height = 200,
					FormBorderStyle = FormBorderStyle.FixedDialog,
					Text = caption,
					StartPosition = FormStartPosition.CenterScreen
				};
				//MessageBox.Show(text);
				Label textLabel = new Label() { Left = 0, Top = 0, Text = text };
				textLabel.AutoSize = true;
				TextBox textBox = new TextBox() { Left = 50, Top = 60, Width = 400 };
				Button confirmation = new Button() { Text = "Ok", Left = 350, Width = 70, Top = 120, DialogResult = DialogResult.OK };
				confirmation.Click += (sender, e) => { prompt.Close(); };
				prompt.Controls.Add(textBox);
				prompt.Controls.Add(confirmation);
				prompt.Controls.Add(textLabel);
				prompt.AcceptButton = confirmation;

				return prompt.ShowDialog() == DialogResult.OK ? textBox.Text : "";
			}
		}
		//To remove any unnecessary files
		public void del_prev_files()
		{
			//string path = System.IO.Directory.GetCurrentDirectory() + "\\List_Of_Items.txt";
			string path1 = System.IO.Directory.GetCurrentDirectory() + "\\revision.txt";
			string p = System.IO.Directory.GetCurrentDirectory() + "\\TCE.txt";
			//string q = System.IO.Directory.GetCurrentDirectory() + "\\indicator.txt";
			//File.Delete(path);
			File.Delete(path1);
			File.Delete(p);
			//File.Delete(q);
		}
		//to create a file containg the filenames
		public void writefile(string path,string s)
		{
			if (!File.Exists(path))
			{
				using (StreamWriter sw = File.CreateText(path))
				{
					sw.WriteLine(s);
					sw.Close();
				}
			}
			else
			{
				using (StreamWriter swr = File.AppendText(path))
				{
					swr.WriteLine(s);
					swr.Close();
				}
			}
		}
		//if the string contains SOP/DWI
		public string SearchForSOPDWI(string s)
		{
			if (s.Contains("SOP") == true)
			{
				for(int i=0;i<s.Count()-3;i++)
				{
					if (s[i] =='S' && s[i+1]=='O'&& s[i+2]=='P')
					{
						string sp = "SOP";
						string numb = "";
						i = i + 3;
						if (s[i] == ' ')
							i = i + 1;
						int start = i;
						//int index = 0;
						int counter = 1;
						while(i<s.Count())
						{
							if (s[i] == '.' || (s[i] >= '0' && s[i] <= '9'))
								counter++ ;
							else
								break;
							i++;
						}
						numb = s.Substring(start, counter-1);
						if(numb.Count()>0)
							return sp + numb;
					}
				}
				return "EXIT";
			}
			if (s.Contains("DWI") == true)
			{
				for (int i = 0; i < s.Count() - 3; i++)
				{
					if (s[i] == 'D' && s[i + 1] == 'W' && s[i+2] == 'I')
					{
						string sp = "DWI";
						string numb = "";
						i = i + 3;
						if (s[i] == ' ')
							i = i + 1;
						else if (s.Substring(i - 2, 3).Contains("-") == true)
							i = i + 1;
						int start = i;
						int counter = 1;
						//int index = 0;
						while (i < s.Count())
						{
							if (s[i] == '.' || (s[i] >= '0' && s[i] <= '9'))
								counter++;
							else
								break;
							i++;
						}
						numb = s.Substring(start, counter - 1);
						if (numb.Count() > 0)
							return sp +"-"+ numb;
					}
				}
				return "EXIT";
			}
			return "EXIT";
		}
		public string RevInSentence(string numbers)
		{
			string s = numbers;
			if (s.Contains(")") == true)
			{
				string[] str = s.Split(')');
				s = str[0];
			}
			if (s.Count() == 1)
			{
				if (s[0] >= 'A' || s[0] < 'Z')
				{
					return s;

				}
			}
			else if (s.Count() == 2)
			{
				if (s[0] >= 'A' || s[0] < 'Z')
				{
					if (s[1] >= 'A' || s[1] < 'Z')
					{
						return s;
					}
					
				}
			
			}
			return "NULL";


		}
		public string JoinFIle(string p, string q)
		{
			Regex rex = new Regex(@"\b.txt\b");
			string[] s = rex.Split(p);
			string a = s[0] + q + ".txt";
			return a;
		}
		public void SetNewFiles(string p,string q)
		{
			string tracker = System.IO.Directory.GetCurrentDirectory() + "\\TempDir\\numberoffiles.txt";
			int count;
			if (File.Exists(tracker)==true)
			{
				using (StreamReader swr = new StreamReader(tracker))
				{
					string numb = swr.ReadToEnd();
					count = Int32.Parse(numb);
					count = count + 1;
					swr.Close();
					File.Delete(tracker);
					using (StreamWriter sw = File.CreateText(tracker))
					{
						sw.WriteLine(count);
						sw.Close();
					}
				}
			}
			else
			{
				count = 1;
				using (StreamWriter sw = File.CreateText(tracker))
				{
					sw.WriteLine(count);
					sw.Close();
				}
			}

			string sp = JoinFIle(p,count.ToString());
			using (StreamWriter swr = File.CreateText(sp))
			{
				
				swr.WriteLine(sp);
				swr.Close();
			}
			string sq = JoinFIle(q,count.ToString());
			using (StreamWriter swr = File.CreateText(sq))
			{
				
				swr.WriteLine(sq);
				swr.Close();
			}	
		}
		//to check if a revision exists int the next line of the document
		public int PotentialRevision(string s)
		{
			int i = 0,count=0;
			string[] line = s.Split('\r');
			if (line.Count() ==0)
				return 0;
			if (line[0].Count() > 2)
				return 0;
			s = line[0];
			for (i = 0; i < s.Count() && i<2; i++)
			{
				if (s[i] >= 'A' && s[i] <= 'Z')
				{
					count++;

				}
				else
				{
					if(s[i]>='a'&& s[i]<='z')
					{
						count = 0;
					}
					break;
				}
			}
			return count;
		}
		//to get the count of number of files in the present run
		public int GetMeCount()
		{
			string tracker = System.IO.Directory.GetCurrentDirectory() + "\\TempDir\\numberoffiles.txt";
			int count = 0; ;
			if (File.Exists(tracker) == true)
			{
				using (StreamReader swr = new StreamReader(tracker))
				{
					string numb = swr.ReadToEnd();
					count = Int32.Parse(numb);
					count = count + 1;
					swr.Close();
					File.Delete(tracker);
					using (StreamWriter sw = File.CreateText(tracker))
					{
						sw.WriteLine(count);
						sw.Close();
					}
					return count;
				}
			}
			else
			{
				count = 1;
				using (StreamWriter sw = File.CreateText(tracker))
				{
					sw.WriteLine(count);
					sw.Close();
				}
				return count;
			}
		}
		private void button1_Click(object sender, EventArgs e)
		{
			//del_prev_files();
			//	Console.WriteLine("U".CompareTo("D"));
			string dir = System.IO.Directory.GetCurrentDirectory() + "\\TempDir";
			Directory.CreateDirectory(dir);
			string path1= System.IO.Directory.GetCurrentDirectory() + "\\TempDir\\TCE.txt";
			string path2 = System.IO.Directory.GetCurrentDirectory() + "\\TempDir\\revision.txt";
			int count_files = GetMeCount();
			path1 = Getpath(path1,count_files);
			path2 = Getpath(path2,count_files);
			start:
			int document = 0;
			string fp = System.IO.Directory.GetCurrentDirectory() + "\\TempDir\\filenames.txt";
			fp = Getpath(fp,count_files);
			if (true)
			{
				//Word doc code here
				string fileName = "";
				OpenFileDialog openFileDialog1 = new OpenFileDialog();
				openFileDialog1.Title = "Select a File";
				if (openFileDialog1.ShowDialog() == DialogResult.OK)
				{
					fileName = openFileDialog1.FileName;
					//MessageBox.Show(fileName);
					string onlyname = System.IO.Path.GetFileName(fileName);//removes path retains only the filename
					if (fileName.Contains("doc") == true)
					{
						writefile(fp,onlyname);
						document = 1;
					}
					else if(fileName.Contains("xls")==true)
					{
						writefile(fp,onlyname);
					}
					else
					{
						MessageBox.Show("File format not supported, please select word/excel!");
						return;
					}
				}
				else
				{
					MessageBox.Show("No file selected");
					return;

				}
				if (document == 1)
				{
					object fn = fileName;
					int count = 0;
					Word.Application word = new Word.Application();
					Document doc = new Document();
					Word.Application objWord = new Word.Application();
					object missing = System.Type.Missing;
					doc = objWord.Documents.Open(ref fn,
							ref missing, ref missing, ref missing, ref missing,
							ref missing, ref missing, ref missing, ref missing,
							ref missing, ref missing, ref missing, ref missing,
							ref missing, ref missing, ref missing);
					String read = string.Empty;
					List<string> inp = new List<string>();
					//string found_text = "";
					int pgnumber = 0;
					for (int i = 0; i < doc.Sentences.Count; i++)
					{
						
						Word.Range str = doc.Sentences[i + 1];
						string numbers = doc.Sentences[i + 1].Text;
						int prespage = (int)str.get_Information(Word.WdInformation.wdActiveEndPageNumber);
						if (prespage > pgnumber)
						{
							pgnumber = prespage;
							Console.WriteLine("Currently Parsing Page Number: " + pgnumber);
						}
						//SOP and DWI code
						try
						{
							//string sd = doc.Sentences[i + 2].Text;
							string f = SearchForSOPDWI(numbers);
							if (f.Contains("EXIT") == false)
							{
								string g = f;
								string l = f.Substring(4);
								//string g = Parse_String(l);
								//MessageBox.Show(l);
								//Sometimes DWi is in format of DWI-6xxxx so to get that doc number we use this condition
								if (matched(l)==true)
								{
									int sch = searchinTCE(path1,path2,l, "DWI");
									if (sch == 0)
										PutRevision(path1,path2,l, "DWI");
								}
								else
								{
									int sch = searchinTCE(path1,path2,f, "NULL");
									if (sch == 0)
										PutRevision(path1, path2, f, "NULL");
								}
							}
						}
						catch(Exception ex)
						{
							//Console.WriteLine();
							//	MessageBox.Show(ex.Message.ToString()+ numbers);
						}
						char[] delimiterChars = { ' ' };
						string prevnumber = "NULL";
						string[] wordis = numbers.Split(delimiterChars);
						int value=0;
						if (wordis.Count() == 1)
						{
							value = PotentialRevision(numbers);
							
						}
						for (int j = 0; j < wordis.Count(); j++)
						{
							string revision="NULL";
							string dummy = wordis[j];
							int passentry = 0;
							if (dummy.ToLower().Contains("revision") == true || dummy.ToLower().Contains("rev") == true)
								passentry = 1;
							wordis[j] = Parse_String(wordis[j]);
							if(passentry==1)
							{
								wordis[j] = "rev";
							}
							
							if (wordis[j].Contains("EXIT") == false)
							{
								if (wordis[j].Contains("/") == true)
								{
									int end = 1;
									if (wordis[j].Count() == 11)
										end = 2;
									revision = wordis[j].Substring(9, end);
									wordis[j] = wordis[j].Substring(0, 8);
								}
								string s = wordis[j];
								count++;
							
								//To accommadate format like 6xxx rev #
								if ((s.ToLower().Contains("revision") == true || s.ToLower().Contains("rev") == true) && matched(prevnumber) == true)//add matched as SOP adn DWi)
								{
									revision = RevInSentence(wordis[j + 1]);
									if (revision.Contains("NULL") == true)
									{
										int pch = PotentialRevision(wordis[j + 1]);
										if (pch > 0)
											revision = wordis[j+1].Substring(0, pch);
									}
									if (revision.Contains("NULL") == false)
									{
										int cha = searchinTCE(path1, path2, prevnumber, revision);
										if (cha == 0)
											PutRevision(path1, path2, prevnumber, revision);
									}
								}
								else
								{
									if (revision.Contains("NULL") == true && matched(s) == true)
									{
										//rev could be nextline so we try tos ee if it is present
										string nextline = doc.Sentences[i + 2].Text;
										int val = PotentialRevision(nextline);
										if (val > 0)
										{
											int cha = searchinTCE(path1, path2, s, nextline.Substring(0, val));
											if (cha == 0)
												PutRevision(path1, path2, s, nextline.Substring(0, val));
										}
									}
									int ch = searchinTCE(path1, path2, s, revision);
									if (ch == 0)
									{
										PutRevision(path1, path2, s, revision);
									}
								}
								if (s.ToLower().Contains("revision") == true || s.ToLower().Contains("rev") == true)
								{
									int ijkl = 0;
								}
								else 
									prevnumber = wordis[j];//prevnumber is either the numebr/rev.
							}
						}
					}					
					doc.Close(Word.WdSaveOptions.wdDoNotSaveChanges);
					MessageBox.Show("Successfully updated the file.\n Press any button to continue... ");
				}
				else if (document == 0)
				{
					// Excel sheet code here
					//string fileName = "";
					int count = 0;
					/*OpenFileDialog openFileDialog1 = new OpenFileDialog();
					openFileDialog1.Title = "Select a Excel File";
					if (openFileDialog1.ShowDialog() == DialogResult.OK)
					{
						// Assign the cursor in the Stream to the Form's Cursor property.
						fileName = openFileDialog1.FileName;
					}*/
					Excel.Application xlApp = new Excel.Application();
					Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(fileName);
					Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[1];
					Excel.Range xlRange = xlWorksheet.UsedRange;
					int rowCount =xlRange.Rows.Count;//xlRange.Rows.Count;
					int colCount = xlRange.Columns.Count;// xlRange.Columns.Count;
					for (int i = rowCount; i > 0; i--)
					{
						if (i%25==0)
						{
							Console.WriteLine("Currently Parsing Row Number: " + i);
						}
						for (int j = 1; j < colCount; j++)
						{

							try
							{
								string wordis = xlRange.Cells[i, j].Value2.ToString();
								try
								{
									//string sd = doc.Sentences[i + 2].Text;
									string numbers = wordis;
									string f = SearchForSOPDWI(numbers);
									if (f.Contains("EXIT") == false)
									{
										string g = f;
										string l = f.Substring(4);
										//string g = Parse_String(l);
										//MessageBox.Show(l);
										if (matched(l) == true)
										{
											int sch = searchinTCE(path1, path2, l, "DWI");
											if (sch == 0)
												PutRevision(path1, path2, l, "DWI");
										}
										else
										{
											int sch = searchinTCE(path1, path2, f, "NULL");
											if (sch == 0)
												PutRevision(path1, path2, f, "NULL");
										}
									}
								}
								catch (Exception ex)
								{
									//	MessageBox.Show(ex.Message.ToString()+ numbers);
								}
								string s = Parse_String(wordis);
								string q = "NULL";
								if (s.Contains("/") == true)
								{
									Regex rex = new Regex(@"\b/\b");
									string[] breaking = rex.Split(s);
									s = breaking[0];
									q = breaking[1];
									//MessageBox.Show(s);
								}
								
								if (s.Contains("EXIT") == false)
								{
									//MessageBox.Show(wordis);
									//Console.WriteLine(s);
									count++;
									int ch=searchinTCE(path1, path2, s,q);
									if (ch == 0)
										PutRevision(path1, path2, s,q);
								}
							}
							catch
							{ }
						}
					}

					MessageBox.Show("Successfully updated the file.\n Press any button to continue...  ");
				}
				else
				{
					goto start;
				}
				return;
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			//string s = "NJKW\r\n";
			//MessageBox.Show(s.Substring(0,2));
			string path1 = System.IO.Directory.GetCurrentDirectory() + "\\TCE.txt"; ;
			//File.Delete(path1);
			//display_file(path1);
			string path2 = System.IO.Directory.GetCurrentDirectory() + "\\revision.txt"; ;
			//display_file(path2);
			string path = System.IO.Directory.GetCurrentDirectory() + "\\TempDir\\indicator.txt";
			if (!File.Exists(path))
			{
				using (StreamWriter sw = File.CreateText(path))
				{
					sw.WriteLine("Created");
				}
			}
			else
			{
				File.Delete(path);
				//MessageBox.Show(path);
				if (!File.Exists(path))
				{
					using (StreamWriter sw = File.CreateText(path))
					{
						sw.WriteLine("Created");
					}
				}
			}
			System.Windows.Forms.Application.Exit();
		}
	}
}
