﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace Sunny_Enter
{
	class Program
	{
		public static int CanProceed()
		{
			string file = System.IO.Directory.GetCurrentDirectory() + "\\TempDir\\canproceed.txt";
			if (File.Exists(file) == true)
			{
				return 100;
			}
			return -100;
		}
		static void Main(string[] args)
		{
			int proceed = -1;
			while(proceed!=100)
			{
				proceed = CanProceed();
			}
		}
	}
}
