﻿//this program takes the TCE#.txt, revision#.txt and filename#.txt from temporary folder to main folder for remaining programs to execute
//# indicates the number of files that are left for processing

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Microsoft.Office.Interop.Excel;
using System.IO;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace FileCreator
{
	class Program
	{
		//helps to generate a filename which is to be processed
		public static string JoinFIle(string p, string q)
		{
			Regex rex = new Regex(@"\b.txt\b");
			string[] s = rex.Split(p);
			string a = s[0] + q + ".txt";
			return a;
		}
		//generates the pathname that is specific to the present run number, if they were 5 files and two files were generaed then it would return FILENAME2.txt
		public static string Getpath(string s, int count)
		{

			string sp = JoinFIle(s, count.ToString());
			return sp;
		}
		
		static int Main(string[] args)
		{
			string file = System.IO.Directory.GetCurrentDirectory() + "\\TempDir\\canproceed.txt";
			if(File.Exists(file)==true)
			{
				File.Delete(file);
			}
			try
			{
				string path = System.IO.Directory.GetCurrentDirectory() + "\\TCE.txt";
				string fp = System.IO.Directory.GetCurrentDirectory() + "\\filenames.txt";
				string path1 = System.IO.Directory.GetCurrentDirectory() + "\\revision.txt";
				string indicator = System.IO.Directory.GetCurrentDirectory() + "\\indicator.txt";

				string path_list = System.IO.Directory.GetCurrentDirectory() + "\\TempDir\\TCE.txt";
				string fp_fileneame = System.IO.Directory.GetCurrentDirectory() + "\\TempDir\\filenames.txt";
				string path1_rev = System.IO.Directory.GetCurrentDirectory() + "\\TempDir\\revision.txt";
				string indicator_ind = System.IO.Directory.GetCurrentDirectory() + "\\TempDir\\indicator.txt";

				string numb = System.IO.Directory.GetCurrentDirectory() + "\\TempDir\\numberoffiles.txt";
				int count = 0;
				using (StreamReader swr = new StreamReader(numb))
				{
					string s = swr.ReadToEnd();
					count = Int32.Parse(s);
					swr.Close();
				}
				string command = "start cmd /k sylmar.bat";
				if (count > 0)
				{
					path_list = Getpath(path_list, count);
					fp_fileneame = Getpath(fp_fileneame, count);
					path1_rev = Getpath(path1_rev, count);
					//indicator_ind = Getpath(indicator_ind, count);
					try
					{
						System.IO.File.Copy(path_list, path, true);
						System.IO.File.Copy(fp_fileneame, fp, true);
						System.IO.File.Copy(path1_rev, path1, true);
						System.IO.File.Copy(indicator_ind, indicator, true);
					}
					catch (Exception e)
					{
						//if no further files are left to process
						Console.WriteLine(e.Message.ToString());
						System.Threading.Thread.Sleep(8000);
						File.Delete(numb);
						using (StreamWriter swr = File.CreateText(numb))
						{
							count = 0;
							swr.WriteLine(count.ToString());
							swr.Close();
						}
						return 1;
					}
					File.Delete(numb);
					using (StreamWriter swr = File.CreateText(numb))
					{
						count = count - 1;
						swr.WriteLine(count.ToString());
						swr.Close();
					}
					System.Diagnostics.Process.Start("CMD.exe", command);
					//waits till FileCOnversion.exe deletes yhis fp. The fp deletion occurs at the end of SunnyvaleTCE execution. 
					//To keep this program waiting till them we use this line
					while (File.Exists(fp) == true)
					{
						int ijk = 0;
					}

				}
			}
			catch(Exception e)
			{
				Console.WriteLine(e.Message.ToString());
				System.Threading.Thread.Sleep(8000);
				string numb = System.IO.Directory.GetCurrentDirectory() + "\\TempDir\\numberoffiles.txt";
				int count = 0;
				File.Delete(numb);
				using (StreamWriter swr = File.CreateText(numb))
				{
					count = 0;
					swr.WriteLine(count.ToString());
					swr.Close();
				}
				return 1;

			}
			return 1;
		}
	}
}
