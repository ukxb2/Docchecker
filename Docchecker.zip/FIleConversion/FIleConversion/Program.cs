﻿//this program is used to put the items present in List_Of_Items in an excel sheet and delete all the intermediate files created.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Excel;
using System.IO;

namespace FIleConversion
{
	class Program
	{
		static void Main(string[] args)
		{
			Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
			//File contains the entries
			string path = System.IO.Directory.GetCurrentDirectory() + "\\List_Of_Items.txt";
			int size = 0;
			List<string> items = new List<string>();
			//File contains the names of all the files parsed
			string fp = System.IO.Directory.GetCurrentDirectory() + "\\filenames.txt";
			int counter = 0;
			int delcount = 0;
			//string[] words;
			string[] words12;
			List<string> dummy = new List<string>();
			try
			{
				using (StreamReader sr = new StreamReader(path))
				{
					string line1 = sr.ReadToEnd();
					//Console.WriteLine(line1);
					List<string> sep = new List<string>();
					//Delimiter for each field is $
					words12 = line1.Split('$');
					size = words12.Count();
					//the following loop checks for duplicate records in the List_Of_Items and if found they are removed
					for (int ls = 0; ls < size; ls++)
						dummy.Add(words12[ls]);
					for (int r1 = 0; r1 < dummy.Count(); r1++)
					{
						for (int r2 = r1 + 1; r2 < dummy.Count(); r2++)
						{
							if (dummy[r2].Equals(dummy[r1]) == true && dummy[r2].Contains("00"))
							{
								int r3;
								for (r3 = r2; r3 < r2 + 4-delcount; r3++)
								{
									dummy.RemoveAt(r2);
									delcount++;
								}
								if (dummy[r3].Contains("Not Released") == true)
									dummy.RemoveAt(r3);
							}
							break;
						}
					}					
				}
			}
			catch { return; }
			string fpnames;
			try
			{
				using (StreamReader sr = new StreamReader(fp))
				{
					string line1 = sr.ReadToEnd();
					fpnames = line1;
				}
			}
			catch { return; }
			//File contains the revision information in the document
			string path1 = System.IO.Directory.GetCurrentDirectory() + "\\revision.txt";
			int size1 = 0;
			List<string> items1 = new List<string>();
			try
			{
				using (StreamReader sr = new StreamReader(path1))
				{
					string line1 = sr.ReadToEnd();
					//Console.WriteLine(line1);
					List<string> sep = new List<string>();
					string[] words1 = line1.Split('\n');
					size1 = words1.Count();
					for (int count = 0; count < size1; count++)
					{
						items1.Add(words1[count]);
					}
				}
			}
			catch { return; }
			//Openigna new excel sheet to put data.
			if (xlApp == null)
			{
				Console.WriteLine("EXCEL could not be started. Check that your office installation and project references are correct.");
				return;
			}
			xlApp.Visible = true;
			Workbook wb = xlApp.Workbooks.Add(XlWBATemplate.xlWBATWorksheet);
			Worksheet ws = (Worksheet)wb.Worksheets[1];

			///
			ws.Activate();
			ws.Application.ActiveWindow.SplitRow = 1;
			ws.Application.ActiveWindow.FreezePanes = true;

			if (ws == null)
			{
				Console.WriteLine("Worksheet could not be created. Check that your office installation and project references are correct.");
			}
			Range aRange = ws.get_Range("C1", "C7");

			if (aRange == null)
			{
				Console.WriteLine("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
			}
			List<string> def = new List<string>();
			//Inserting the field names
			def.Add("Document Number");
			def.Add("Revision in Document");
			def.Add("Latest Released Revision in TCE");
			def.Add("Description");
			def.Add("Release Date");
			//def.Add("Comments");
			ws.Columns["C"].ColumnWidth = 20;
			ws.Columns["D"].ColumnWidth = 90;
			ws.Columns["E"].ColumnWidth = 20;
			ws.Columns["A"].ColumnWidth = 20;
			ws.Columns["B"].ColumnWidth = 20;
			//ws.Columns["F"].ColumnWidth = 70;
			for (int cols = 1; cols < 7-1; cols++)
			{
				aRange.Cells[1, cols - 2] = def[cols - 1];
			}
			aRange.Rows[1].EntireRow.Font.Bold = true;
			aRange.Rows[1].EntireRow.Font.Bold = true;
			int index1 = 0;//to keep track of number of records in the list_of_items

			int tracker = 0, i = 2, j = 1,rows=0;// i=2, j=1 is assigned only for visualization purpose. They play no role in the code
			try
			{				
				for (rows = i; (rows<(dummy.Count()-1-counter)/4+2||rows<index1-2 )&& index1<dummy.Count()-3; rows++)
				{
					//Console.WriteLine(rows);
					//code not used
					if(dummy[index1].Contains("newfile")==true)
					{
						index1 = index1 + 4;
						rows = rows - 1;
					}
					//string[] insert = items[index++].Split('$');// the delimiter used is '$' can be changed in the .C file if needed	
					//this will help keep track if index1 is not updated in a loop
					if (tracker != index1)
					{
						tracker = index1;
					}
					else
					{
						
						if(tracker!=0)
						{
							//rows = rows - 1;
							int addition = 4;//4 because definitely there will be 4 fields to enter
							if (index1 + addition <= dummy.Count())
							{
								if (dummy[index1 + addition].ToLower().Contains("released on") == true)
									addition = 5;
								if (index1 + addition < dummy.Count())
									index1 = index1 + addition;
								else
									break;
							}
						}
					}
					//int canenter = 1;
					int cols = j;
						// To remove special characters if the latest release does not exist
						//Since col 3 is reserved for revision in document
						if (true )
						{
							int changeRow = 0;// variable will indicate if the present row in the excel sheet will be written with a record or not.
							for (int find = 0; find < items1.Count() - 1; find++)
							{
							
							    string[] split = items1[find].Split(' ');
								if (split[0].Contains("new") == true)
									items1[find + 1] = "dummy file";							
								if (dummy[index1].Contains(split[0]) == true)
								{

									aRange.Cells[rows, cols - 2] = dummy[index1++];
								    string check = dummy[index1];
									aRange.Cells[rows, cols - 1] = split[1];
									if (split[1].Contains("DWI")==true)
									{
										aRange.Cells[rows, cols - 2] = "DWI-" + dummy[index1 - 1];
										string insert = split[1];
										insert = insert.Replace("DWI&","");
										aRange.Cells[rows, cols-1] = insert;
										split[1] = insert;
									}
									aRange.Cells[rows, 1] = dummy[index1++];
									aRange.Cells[rows, cols+1] = dummy[index1++];
									aRange.Cells[rows, cols + 2] = dummy[index1++];
								
									if (dummy[index1].Contains("released on") == true)
									{
										string str = dummy[index1];
										StringBuilder sb = new StringBuilder();
										for (int spl = 0; spl < dummy[index1].Count(); spl++)
										{
											if ((str[spl] >= '0' && str[spl] <= '9') || (str[spl] >= 'A' && str[spl] <= 'z' || (str[spl] == '.' || str[spl] == '_') || str[spl] == ' '))
											{
												sb.Append(str[spl]);
											}
										}
										string dwi = "";
										
										string[] splitter = (sb.ToString()+dwi).Split(' ');
									//THIS WILL HELP IN REPLACING THE LATEST REVISION AND RELEASE DATE
									if (splitter[2].Contains("NA") == false)
									{
										check = splitter[2];
										aRange.Cells[rows, 1] = splitter[2];
										string iString = splitter[5] + " " + splitter[6].Substring(0, 2) + ":" + splitter[6].Substring(2);
										aRange.Cells[rows, cols + 2] = iString;
									}
										index1++;
										counter++;
									 }
									for (int loop = 0; loop < check.Count(); loop++)
									{
										if (check[loop] != split[1][loop] && split[1].Contains("NULL") == false)
										{
										//Console.WriteLine(check[loop]+" "+split[1][loop]);
											aRange.Cells[rows, cols - 1].Interior.Color = XlRgbColor.rgbRed;
										}
									}
								items1[find] = "not applicable";
									 changeRow=0;
									 break;									
								}
							else
								changeRow = 1;
							}
							//this would eman that no entry ahs been made in that particular row
							if (changeRow == 1)
								rows = rows - 1;		
						}

				}
			}
			catch(Exception ex)
			{
				Console.WriteLine(ex.Message.ToString());
			}		
			size = dummy.Count()-counter;
			//to find out the number of rows
			size = rows;
			aRange.Cells[size+4,2] = "File(s) parsed ";
			aRange.Rows[size+4].EntireRow.Font.Bold = true;
		
			aRange.Cells[size+5,2]= fpnames;
			string p = System.IO.Directory.GetCurrentDirectory() + "\\TCE.txt";
			string q = System.IO.Directory.GetCurrentDirectory() + "\\indicator.txt";
			//return;
			//delete the temporary files.
			try
			{
			File.Delete(p);
				File.Delete(path);
				File.Delete(q);
				File.Delete(path1);
				File.Delete(fp);
			}
			catch
			{ return; }
		}
	}
}
