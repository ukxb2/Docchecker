﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace CanIProceed
{
	class Program
	{
		static void Main(string[] args)
		{
			string file = System.IO.Directory.GetCurrentDirectory() + "\\TempDir\\canproceed.txt";
			int pro = 0;
			using (StreamWriter sw = File.CreateText(file))
			{
				sw.WriteLine(pro.ToString());
				sw.Close();
				//Console.WriteLine("Created");
			}
			
		}
	}
}
