﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CleanUp
{
	class Program
	{
		static void Main(string[] args)
		{
			string p = System.IO.Directory.GetCurrentDirectory() + "\\TCE.txt";
			string q = System.IO.Directory.GetCurrentDirectory() + "\\indicator.txt";
			string path = System.IO.Directory.GetCurrentDirectory() + "\\List_Of_Items.txt";
			string fp = System.IO.Directory.GetCurrentDirectory() + "\\filenames.txt";
			string path1 = System.IO.Directory.GetCurrentDirectory() + "\\revision.txt";
			string[] files = { "TCE.txt", "indicator.txt", "List_Of_Items.txt", "filenames.txt", "revision.txt" };
			//return;
			for (int i = 0; i < 5; i++)
			{
				try
				{
					File.Delete(files[i]);
				}
				catch { }
			}
			try
			{
				string path2 = System.IO.Directory.GetCurrentDirectory() + "\\TempDir";
				Directory.Delete(path2,true);
			}
			catch { }
			}
	}
}
